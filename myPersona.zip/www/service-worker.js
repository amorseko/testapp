function activate() {
  //
}

function fetch() {
  //
}

function push() {
  //
}

self.addEventListener('activate', activate);
self.addEventListener('fetch', fetch);
self.addEventListener('push', push);
