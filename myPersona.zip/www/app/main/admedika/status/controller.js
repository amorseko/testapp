(function _AppMainAdmedikaStatusController_() {
  'use strict';

  /**
   * @ngdoc controller
   * @name app.main.admedika.status.controller:MainAdmedikaStatusController
   *
   * @description
   * AdMedika status controller.
   */
  function MainAdmedikaStatusController() {

  }

  angular.module('app.main.admedika.status').controller('MainAdmedikaStatusController', MainAdmedikaStatusController);
}());
