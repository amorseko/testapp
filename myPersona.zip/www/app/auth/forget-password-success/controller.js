(function _AppAuthForgetPasswordSuccessController_() {
  'use strict';

  /**
   * @ngdoc controller
   * @name app.auth.forget-password-success.controller:AuthForgetPasswordSuccessController
   *
   * @description
   * Forget password success controller.
   */
  function AuthForgetPasswordSuccessController() {

  }

  angular.module('app.auth.forget-password-success').controller('AuthForgetPasswordSuccessController', AuthForgetPasswordSuccessController);
}());
